package contact;
import java.util.ArrayList;
public class ContactService {
	public ArrayList<Contact> contacts;
	
	public ContactService() {
		contacts = new ArrayList<>();
	}
	public boolean isContact(Contact contact) {
		boolean contactExists = false;
		for (Contact iter:contacts) {
			if(iter.getContactID().equals(contact.getContactID())) {
				contactExists = true;
			}
		}
		return contactExists;
	}
	public void deleteContact(String contactID) {
		for(Contact iter:contacts) {
			if(iter.getContactID().equals(contactID)) {
				contacts.remove(iter);
			}
		}
	}
	public void addContact(String contactID,String firstName,String lastName,String phoneNum,String address) {
		Contact contact = new Contact(contactID,firstName,lastName,phoneNum,address);
		if(!isContact(contact)) {
			contacts.add(contact);
		}
	}
	public void updateFirstName(String contactID,String firstName){
		for(Contact iter:contacts) {
			if(iter.getContactID().equals(contactID)) {
				iter.setFirstName(firstName);
			}
		}
	}
	public void updateLastName(String contactID,String lastName){
		for(Contact iter:contacts) {
			if(iter.getContactID().equals(contactID)) {
				iter.setLastName(lastName);
			}
		}
		
	}
	public void updatePhoneNum(String contactID,String phoneNum){
		for(Contact iter:contacts) {
			if(iter.getContactID().equals(contactID)) {
				iter.setPhoneNum(phoneNum);
			}
		}
		
	}
	public void updateAddress(String contactID,String address){
		for(Contact iter:contacts) {
			if(iter.getContactID().equals(contactID)) {
				iter.setAddress(address);
			}
		
		}
	}
}
