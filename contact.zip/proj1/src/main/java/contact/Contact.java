package contact;

public class Contact {
	private String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	public void setContactID(String contactID) {
		if (contactID == null || contactID.length() > 10){
			throw new IllegalArgumentException("Invalid ID");

		}
		this.contactID = contactID;
	}
	public String getContactID() {
		return contactID;
	}
	public void setFirstName(String firstName) {
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid Name");
		}
		this.firstName = firstName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setLastName(String lastName) {
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Name");
		}
		this.lastName = lastName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setPhoneNum(String phoneNumber) {
		if(phoneNumber.length() == 10) {
			this.phoneNumber = phoneNumber;
		}
		else {
			throw new IllegalArgumentException("Invalid phone number");
		}
	}
	public String getPhoneNum() {
		return phoneNumber;
	}
	public void setAddress(String address) {
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	public Contact(String contactID, String firstName, String lastName, String phoneNum, String address) {
		setContactID(contactID);
		setFirstName(firstName);
		setLastName(lastName);
		setPhoneNum(phoneNum);
		setAddress(address);
	}
}
