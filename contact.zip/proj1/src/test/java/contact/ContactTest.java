package contact;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;



public class ContactTest {

	@Test
	public void testContact() {
		Contact contact = new Contact("10101","Samantha","Godwin","0123456789","Example text");
		assertTrue(contact.getFirstName().equals("Samantha"));
		assertTrue(contact.getContactID().equals("10101"));
		assertTrue(contact.getLastName().equals("Godwin"));
		assertTrue(contact.getAddress().equals("Example text"));
		assertTrue(contact.getPhoneNum().equals("0123456789"));
	}
	@Test
	public void testInvalidPhone() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("10101","Samantha","Godwin","01234567890","Example text");
		});
	}
	@Test
	public void testFirstNameTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("10101","MANYMANYMANYCHARACTERS","Godwin","01234567890","Example text");
		});
	}
	@Test
	public void testLastNameTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("10101","Samantha","MANYMANYMANYCHARACTERS","01234567890","Example text");
		});
	}
	@Test
	public void testAddressTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("10101","Samantha","Godwin","01234567890","It's not like I am gonna give out my actual legal address like no offence");
		});
	}
	@Test
	public void testNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null,"Samantha","Godwin","01234567890","now testing null");
		});
	}
}
