package contact;

import static org.junit.Assert.*;

import org.junit.Test;

public class ContactServiceTest {

	@Test
	public void testAddContact() {
		ContactService contactService = new ContactService();
		contactService.addContact("10101","Samantha","Godwin","0123456789","Example text");
		Contact testObj = new Contact("10101","Samantha","Godwin","0123456789","Example text");
		assertTrue(contactService.contacts.get(0).getContactID().equals(testObj.getContactID()));
	}
	@Test
	public void testDuplicateAdd() {
		ContactService contactService = new ContactService();
		contactService.addContact("10101","Samantha","Godwin","0123456789","Example text");
		contactService.addContact("10101","Samantha","Godwin","0123456789","Example text");
		assertTrue(contactService.contacts.size() == 1);
	}
	@Test
	public void testDeleteContact() {
		ContactService contactService = new ContactService();
		contactService.addContact("10101","Samantha","Godwin","0123456789","Example text");
		contactService.addContact("10102","Samantha","Godwin","0123456789","Example text");
		assertTrue(contactService.contacts.size() == 2);
		contactService.deleteContact("10101");
		assertTrue(contactService.contacts.size()== 1);
	}
	@Test
	public void testUpdateFirstName() {
		ContactService contactService = new ContactService();
		contactService.addContact("10101","Sam","Godwin","0123456789","Example text");
		contactService.updateFirstName("10101", "Samantha");
		assertTrue(contactService.contacts.get(0).getFirstName().equals("Samantha"));
	}
	@Test
	public void testUpdateLastName() {
		ContactService contactService = new ContactService();
		contactService.addContact("10101","Samantha","Godwin","0123456789","Example text");
		contactService.updateLastName("10101", "Price");
		assertTrue(contactService.contacts.get(0).getLastName().equals("Price"));
	}
	@Test
	public void testUpdatePhoneNum() {
		ContactService contactService = new ContactService();
		contactService.addContact("10101","Samantha","Godwin","0123456789","Example text");
		contactService.updatePhoneNum("10101", "6969696969");
		assertTrue(contactService.contacts.get(0).getPhoneNum().equals("6969696969"));
	}
	@Test
	public void testUpdateAddress() {
		ContactService contactService = new ContactService();
		contactService.addContact("10101","Samantha","Godwin","0123456789","Example text");
		contactService.updateAddress("10101", "6969696969");
		assertTrue(contactService.contacts.get(0).getAddress().equals("6969696969"));
	}
}


